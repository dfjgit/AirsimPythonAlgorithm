# DQN V2 快速开始

最简单的实现版本 - 使用Stable-Baselines3训练APF权重

---

## 🚀 快速开始（3步）

### 步骤1: 安装依赖

```bash
# 基础依赖
pip install stable-baselines3 torch gym

# 可选：如果想要进度条（需要额外依赖）
# pip install stable-baselines3[extra]
```

**注意**: 当前版本已禁用进度条，无需安装额外依赖。

### 步骤2: 训练模型

```bash
cd multirotor/DQN
python train_simple.py
```

**预期输出**：
```
==============================================================
简单DDPG训练 - APF权重学习
==============================================================

检查依赖...
✓ PyTorch: 2.x.x
✓ Stable-Baselines3已安装

==============================================================
步骤1: 创建训练环境
==============================================================
✓ 环境创建成功
  观察空间: (18,)
  动作空间: (5,)

==============================================================
步骤2: 创建DDPG模型
==============================================================
✓ DDPG模型创建成功

==============================================================
步骤3: 开始训练
==============================================================
训练步数: 10000
预计时间: 约10分钟

[训练进度条...]

✓ 训练完成！

==============================================================
步骤4: 保存模型
==============================================================
✓ 模型已保存: models/weight_predictor_simple.zip
```

### 步骤3: 测试模型

```bash
python test_trained_model.py
```

**预期输出**：
```
==============================================================
测试训练好的权重预测模型
==============================================================

加载模型: models/weight_predictor_simple.zip
✓ 模型加载成功

==============================================================
测试场景1: 随机状态
==============================================================

测试 1:
  状态: pos=(5.2, 3.1, 1.8), entropy=45.3
  预测权重:
    α1 (排斥力)  = 2.34
    α2 (熵)      = 3.12
    α3 (距离)    = 1.89
    α4 (Leader)  = 2.67
    α5 (方向)    = 2.45

[更多测试...]

✓ 模型可以正常预测权重
```

---

## 📝 代码说明

### 核心文件

#### 1. simple_weight_env.py
**环境定义**：
- 状态空间：18维（位置、速度、方向、熵值等）
- 动作空间：5维连续（5个权重系数）
- 奖励函数：探索奖励 - 碰撞惩罚 - 越界惩罚

**关键代码**：
```python
class SimpleWeightEnv(gym.Env):
    def __init__(self, server=None, drone_name="UAV1"):
        # 观察空间: 18维
        self.observation_space = spaces.Box(
            low=-100.0, high=100.0, shape=(18,), dtype=np.float32
        )
        
        # 动作空间: 5个权重 [0.1, 10.0]
        self.action_space = spaces.Box(
            low=0.1, high=10.0, shape=(5,), dtype=np.float32
        )
    
    def step(self, action):
        # action = [α1, α2, α3, α4, α5]
        # 设置权重到APF算法
        # 计算奖励
        # 返回 next_state, reward, done, info
```

#### 2. train_simple.py
**训练脚本**：
- 创建环境
- 创建DDPG模型
- 训练10000步
- 保存模型

**关键参数**：
```python
model = DDPG(
    "MlpPolicy",              # 多层感知机策略
    env,
    learning_rate=1e-3,       # 学习率
    buffer_size=10000,        # 经验回放缓冲区
    batch_size=64,            # 批次大小
    gamma=0.99                # 折扣因子
)
```

#### 3. test_trained_model.py
**测试脚本**：
- 加载训练好的模型
- 测试不同场景
- 验证权重预测

---

## 🎯 当前实现特点

### 简化设计
- ✅ 无需真实server（可以独立训练）
- ✅ 使用模拟数据
- ✅ 最小依赖
- ✅ 快速验证

### 核心功能
- ✅ 18维状态空间
- ✅ 5维连续动作（权重）
- ✅ DDPG算法
- ✅ 奖励函数

### 限制
- ⚠️ 当前使用模拟数据（无真实server）
- ⚠️ 奖励函数简化
- ⚠️ 未连接真实仿真环境

---

## 🔄 下一步扩展

### 扩展1: 连接真实环境

修改 `train_simple.py`：
```python
# 导入AlgorithmServer
from multirotor.AlgorithmServer import MultiDroneAlgorithmServer

# 创建server
server = MultiDroneAlgorithmServer()
server.start()

# 创建环境（连接真实server）
env = SimpleWeightEnv(server=server, drone_name="UAV1")

# 训练（会使用真实数据）
model.learn(total_timesteps=10000)
```

### 扩展2: 转换为ONNX

```python
# 导出为ONNX（需要额外实现）
import torch

# 提取Actor网络
actor = model.actor

# 导出
dummy_input = torch.randn(1, 18)
torch.onnx.export(
    actor,
    dummy_input,
    "models/weight_predictor.onnx",
    input_names=['state'],
    output_names=['weights']
)
```

### 扩展3: 集成到AlgorithmServer

在 `AlgorithmServer.py` 中添加：
```python
def __init__(self, use_learned_weights=False):
    # ...
    if use_learned_weights:
        self.weight_model = DDPG.load("DQN/models/weight_predictor_simple")

def _get_weights(self, drone_name):
    if self.weight_model:
        state = self._get_state(drone_name)
        weights, _ = self.weight_model.predict(state)
        return weights  # [α1, α2, α3, α4, α5]
    else:
        # 使用配置文件权重
        return [2.0, 2.0, 2.0, 2.0, 2.0]
```

---

## 🧪 验证清单

### 基础验证
- [ ] `simple_weight_env.py` 可以独立运行
- [ ] `train_simple.py` 可以完成训练
- [ ] `test_trained_model.py` 可以加载和测试模型
- [ ] 模型文件生成在 `models/` 目录

### 功能验证
- [ ] 模型能预测5个权重
- [ ] 权重在有效范围内 [0.1, 10.0]
- [ ] 不同状态得到不同权重
- [ ] 训练曲线收敛

---

## 🐛 常见问题

### Q: 报错 "You must install tqdm and rich"
A: 两种解决方案：
```bash
# 方案1: 安装额外依赖（推荐）
pip install tqdm rich

# 方案2: 已在代码中禁用进度条（progress_bar=False）
# 无需额外操作
```

### Q: 训练很慢怎么办？
A: 减少 `total_timesteps`，例如改为5000或更少
```python
total_timesteps = 5000  # 减少到5000步
```

### Q: 模型预测的权重都一样？
A: 可能是训练不充分，增加训练步数或调整学习率
```python
total_timesteps = 20000  # 增加训练步数
```

### Q: 如何查看训练进度？
A: 观察控制台输出，每10个episode会显示：
```
---------------------------------
| rollout/            |         |
|    ep_len_mean      | 200     |
|    ep_rew_mean      | 5.23    |
| time/               |         |
|    episodes         | 10      |
|    fps              | 245     |
|    total_timesteps  | 2000    |
---------------------------------
```

### Q: 如何调整训练参数？
A: 修改 `train_simple.py` 中的DDPG参数：
```python
model = DDPG(
    ...,
    learning_rate=1e-4,    # 降低学习率
    batch_size=128,        # 增大批次
    buffer_size=50000      # 增大缓冲区
)
```

### Q: 训练时CPU占用很高？
A: 这是正常的，训练需要计算资源。可以：
- 减少batch_size
- 降低训练频率
- 或在GPU机器上训练

---

## 📊 预期效果

### 训练后的模型应该能：
- ✅ 在高熵值区域：提高α2（熵权重）
- ✅ 在低熵值区域：提高α3（距离权重）
- ✅ 靠近其他无人机：提高α1（排斥力权重）
- ✅ 远离Leader：提高α4（Leader范围权重）
- ✅ 运动不稳定：提高α5（方向保持权重）

### 性能指标
- 训练时间：约10分钟（10000步）
- 模型大小：约5MB
- 推理速度：<10ms（CPU）

---

## 🎓 学习资源

### Stable-Baselines3文档
- [DDPG算法](https://stable-baselines3.readthedocs.io/en/master/modules/ddpg.html)
- [自定义环境](https://stable-baselines3.readthedocs.io/en/master/guide/custom_env.html)

### 代码示例
- [Gym环境教程](https://www.gymlibrary.dev/content/environment_creation/)
- [DDPG训练示例](https://github.com/DLR-RM/stable-baselines3/blob/master/docs/guide/examples.rst)

---

## 💡 提示

1. **先独立训练**：不连接server，使用模拟数据快速验证
2. **观察权重变化**：看模型是否学到了合理的策略
3. **逐步集成**：先测试，再集成到真实环境
4. **保存检查点**：训练过程中定期保存模型

---

**创建日期**: 2025-10-13  
**难度**: ⭐⭐ (简单)  
**预计时间**: 30分钟

