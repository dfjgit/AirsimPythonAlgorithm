# DQN使用指南

AirSim无人机仿真系统的DQN强化学习模块完整使用指南

---

## 📋 概述

本项目提供了两种DQN强化学习实现方案，分别针对不同的控制策略：

### 🚁 DQN移动控制 (DQN_Movement)
- **算法**: DQN (Deep Q-Network)
- **动作空间**: 6个离散动作（上/下/左/右/前/后）
- **观察空间**: 21维状态（位置、速度、熵值、Leader信息等）
- **控制方式**: AI直接决策下一步往哪个方向移动

### ⚖️ DQN权重学习 (DQN_Weight)
- **算法**: DDPG (Deep Deterministic Policy Gradient)
- **动作空间**: 5个连续权重系数（α1-α5: 排斥力、熵值、距离、Leader范围、方向保持）
- **观察空间**: 18维状态（位置、速度、熵值、Leader信息等）
- **控制方式**: AI动态调整APF算法的5个权重参数，间接影响移动行为

---

## 🆚 两种方案对比

| 特性 | DQN_Movement | DQN_Weight |
|------|-------------|-----------|
| **算法** | DQN | DDPG |
| **动作类型** | 离散动作（6个方向） | 连续动作（5个权重） |
| **动作空间** | `Discrete(6)` | `Box(5)` |
| **控制层级** | 底层（直接控制移动） | 高层（调整行为策略） |
| **响应速度** | 快速直接 | 通过APF间接响应 |
| **灵活性** | 固定6个方向 | 无限连续权重组合 |
| **复杂度** | 相对简单 | 相对复杂 |
| **训练时间** | 10-30分钟 | 15-40分钟 |
| **可解释性** | 较低（黑盒决策） | 较高（可观察权重变化） |
| **与APF结合** | 独立于APF | 增强APF算法 |

---

## 🎯 选择指南

### 选择 DQN_Movement（移动控制）如果：
- ✅ 你想直接学习移动策略
- ✅ 场景相对简单
- ✅ 需要快速原型验证
- ✅ 第一次使用强化学习

### 选择 DQN_Weight（权重APF）如果：
- ✅ 已有APF算法框架
- ✅ 需要调整复杂行为
- ✅ 场景需要精细控制
- ✅ 追求更优的性能

---

## 🚁 DQN移动控制详细指南

### 📁 文件结构
```
DQN_Movement/
├── movement_env.py                    # 无人机移动环境类（核心）⭐
├── movement_dqn_config.json          # 配置文件（奖励、阈值、训练参数）
├── train_movement_dqn.py             # 纯模拟训练脚本
├── train_movement_with_airsim.py    # AirSim集成训练脚本
├── test_movement_dqn.py              # 模型测试脚本
├── requirements_movement.txt         # Python依赖
├── logs/                             # 训练日志目录
└── models/                           # 训练模型保存目录
```

### 🚀 快速开始

#### 1. 环境准备
```bash
pip install torch stable-baselines3 numpy gymnasium
```

#### 2. 纯模拟训练（推荐入门）
```bash
# Windows
train_movement_dqn.bat

# 或者直接运行Python
python multirotor/DQN_Movement/train_movement_dqn.py
```

#### 3. AirSim集成训练（真实环境）
```bash
# 1. 先启动Unity客户端
# 2. 运行训练脚本
train_movement_with_airsim.bat
```

#### 4. 测试模型
```bash
test_movement_dqn.bat
```

### ⚙️ 配置说明

#### 移动参数
```json
{
  "step_size": 1.0,        // 每步移动距离（米）
  "max_steps": 500         // 每个episode最大步数
}
```

#### 奖励设计
```json
{
  "exploration": 10.0,          // 发现新区域奖励
  "entropy_reduction": 5.0,     // 降低熵值奖励
  "collision": -50.0,           // 碰撞惩罚
  "out_of_range": -30.0,        // 越界惩罚
  "smooth_movement": 1.0,       // 平滑移动奖励
  "step_penalty": -0.1,         // 每步小惩罚
  "success": 100.0              // 完成任务大奖励
}
```

#### 训练参数
```json
{
  "total_timesteps": 100000,           // 训练总步数
  "learning_rate": 0.0001,            // 学习率
  "buffer_size": 50000,               // 经验回放缓冲区
  "batch_size": 32,                   // 批次大小
  "gamma": 0.99,                      // 折扣因子
  "exploration_fraction": 0.3,        // 探索衰减比例
  "exploration_initial_eps": 1.0,     // 初始探索率
  "exploration_final_eps": 0.05       // 最终探索率
}
```

### 📊 状态空间详解

环境观察空间为21维向量：

| 维度范围 | 名称 | 说明 |
|---------|------|------|
| 0-2 | 位置 | x, y, z坐标 |
| 3-5 | 速度 | vx, vy, vz速度分量 |
| 6-8 | 朝向 | forward向量 |
| 9-11 | 局部熵值 | 平均熵、最大熵、熵标准差 |
| 12-14 | Leader相对位置 | dx, dy, dz |
| 15-16 | Leader范围信息 | 距离、是否越界 |
| 17-19 | 扫描进度 | 已扫描比例、数量、剩余 |
| 20 | 最近无人机距离 | 避障用 |

### 🎮 动作空间详解

6个离散动作：

| 动作ID | 方向 | 位移向量 |
|--------|------|---------|
| 0 | 上 | (0, 0, +step_size) |
| 1 | 下 | (0, 0, -step_size) |
| 2 | 左 | (-step_size, 0, 0) |
| 3 | 右 | (+step_size, 0, 0) |
| 4 | 前 | (0, +step_size, 0) |
| 5 | 后 | (0, -step_size, 0) |

---

## ⚖️ DQN权重学习详细指南

### 📁 文件结构
```
DQN_Weight/
├── simple_weight_env.py    # 权重学习环境
├── train_simple.py         # 训练脚本
├── test_trained_model.py   # 测试脚本
├── dqn_reward_config.json  # 配置文件
├── models/                 # 训练模型保存目录
└── logs/                   # 训练日志目录
```

### 🚀 快速开始

#### 1. 纯模拟训练
```bash
cd multirotor/DQN_Weight
python train_simple.py
```

#### 2. AirSim集成训练
```bash
python train_with_airsim.py
```

#### 3. 测试模型
```bash
python test_trained_model.py
```

### ⚙️ 权重平衡机制

#### 问题描述
DQN模型可能学习到极端的权重组合，导致：
- 某个权重占主导地位
- APF算法失衡
- 无人机行为异常

#### 解决方案

**1. 缩小权重范围**
```python
# 动作空间
self.action_space = spaces.Box(
    low=0.5,   # 最小权重
    high=5.0,  # 最大权重
    shape=(5,),
    dtype=np.float32
)
```

**2. 软归一化**
```python
action_mean = np.mean(action)
action_std = np.std(action)

# 如果标准差过大（>1.5），进行平滑
if action_std > 1.5:
    # 将极端值拉回到均值附近（保留70%的差异）
    action = action_mean + (action - action_mean) * 0.7
    action = np.clip(action, 0.5, 5.0)
```

**3. 比例限制**
```python
min_weight = np.min(action)
max_weight = np.max(action)

# 最大值不超过最小值的5倍
if max_weight > min_weight * 5:
    scale = (min_weight * 5) / max_weight
    action = action * scale
    action = np.clip(action, 0.5, 5.0)
```

### 📊 权重平衡流程

```
模型输出原始权重
    ↓
范围裁剪 [0.5, 5.0]
    ↓
计算均值和标准差
    ↓
标准差 > 1.5?
    ├─ 是 → 软归一化（拉回均值）
    └─ 否 → 继续
    ↓
计算最大/最小比例
    ↓
比例 > 5?
    ├─ 是 → 缩放权重
    └─ 否 → 继续
    ↓
最终平衡权重
    ↓
应用到APF算法
```

---

## 📈 训练监控

### 使用Tensorboard查看训练曲线

```bash
# 纯模拟训练日志
tensorboard --logdir=multirotor/DQN_Movement/logs/movement_dqn/

# AirSim集成训练日志
tensorboard --logdir=multirotor/DQN_Movement/logs/movement_dqn_airsim/

# 权重DQN训练日志
tensorboard --logdir=multirotor/DQN_Weight/logs/
```

### 关键指标

- **ep_rew_mean**: 平均episode奖励（越高越好）
- **ep_len_mean**: 平均episode长度（太长说明效率低）
- **exploration_rate**: 探索率（逐渐衰减到0.05）
- **loss**: 训练损失（应该逐渐下降）

---

## 🔧 常见问题

### Q1: 训练很慢怎么办？

**A**: 
- 使用GPU: 确保安装了PyTorch GPU版本
- 减少训练步数: 修改 `total_timesteps`
- 增大批次: 修改 `batch_size` (需要更多内存)
- 使用纯模拟模式: 不连接Unity

### Q2: 模型性能不好？

**A**:
- 调整奖励权重: 增加探索奖励，减少惩罚
- 增加训练时间: 提高 `total_timesteps`
- 调整探索率: 延长探索时间 `exploration_fraction`
- 检查数据: 确保环境状态正确

### Q3: 如何继续训练已有模型？

**A**:
```python
# 在训练脚本中会自动检测
# 也可以手动加载
model = DQN.load("models/movement_dqn_final.zip", env=env)
model.learn(total_timesteps=50000)  # 继续训练
```

### Q4: 权重预测失衡怎么办？

**A**:
- 检查权重平衡机制是否启用
- 调整平衡参数（标准差阈值、比例限制）
- 查看可视化面板中的权重条
- 重新训练模型

---

## 🎓 高级用法

### 自定义奖励函数

编辑环境文件中的 `_calculate_reward` 方法：

```python
def _calculate_reward(self, action, prev_state, next_state):
    reward = 0.0
    
    # 添加自定义奖励
    # 例如：鼓励向高熵区域移动
    entropy_diff = next_state[9] - prev_state[9]  # 第9维是平均熵
    if entropy_diff > 0:
        reward += 2.0  # 移向高熵区域
    
    # ... 其他奖励计算
    return reward
```

### 使用不同的算法

Stable-Baselines3支持多种算法：

```python
from stable_baselines3 import DQN, A2C, PPO

# 使用PPO代替DQN
model = PPO("MlpPolicy", env, ...)
```

### 并行训练

```python
from stable_baselines3.common.vec_env import SubprocVecEnv

# 创建多个并行环境
def make_env():
    return MovementEnv(server=None, drone_name="UAV1")

env = SubprocVecEnv([make_env for _ in range(4)])  # 4个并行环境
model = DQN("MlpPolicy", env, ...)
```

---

## 📝 与现有系统集成

### 在AlgorithmServer中使用

在 `AlgorithmServer.py` 中集成训练好的模型：

```python
from stable_baselines3 import DQN

class MultiDroneAlgorithmServer:
    def __init__(self, use_dqn_movement=False):
        # ...
        if use_dqn_movement:
            self.dqn_model = DQN.load("path/to/movement_dqn_final.zip")
    
    def _control_loop(self, drone_name):
        # 使用DQN预测动作
        obs = self._get_observation(drone_name)
        action = self.dqn_model.predict(obs, deterministic=True)[0]
        self._apply_action(drone_name, action)
```

---

## 📚 参考资料

- [Stable-Baselines3 文档](https://stable-baselines3.readthedocs.io/)
- [DQN原论文](https://arxiv.org/abs/1312.5602)
- [DDPG原论文](https://arxiv.org/abs/1509.02971)
- [OpenAI Gym 文档](https://www.gymlibrary.dev/)

---

## 🤝 贡献

如果您有改进建议或发现问题，欢迎提出Issue或Pull Request。

---

**最后更新**: 2025-01-16
